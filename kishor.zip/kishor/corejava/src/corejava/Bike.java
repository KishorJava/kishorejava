package corejava;
import java.util.*;
public class Bike {
	BikeSpecifications bs=new BikeSpecifications();
	public void hero() {
		
		bs.setMilege(70);
		bs.setModel("passion");
		bs.setMaxspeed(150);
		bs.setPrice(60000);
		}
	public void tvs() {
		
		bs.setMilege(40);
		bs.setModel("apache");
		bs.setMaxspeed(250);
		bs.setPrice(115000);
	}
	
	
	public void ducati() {
		
		bs.setMilege(20);
		bs.setModel("ducati1");
		bs.setMaxspeed(280);
		bs.setPrice(1115000);
	}
	public void display() {
	
		System.out.println("milage ="+bs.getMilege());
		System.out.println("model name ="+bs.getModel());
		System.out.println("max speed ="+bs.getMaxspeed());
		System.out.println("price ="+bs.getPrice());
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
	System.out.println("enter bike name==");
	String b=sc.next();
	
		Bike bk=new Bike();
		if(b.equals("hero"))
		{
			bk.hero();
			bk.display();
		
		
		}
		else if(b.equals("tvs"))
		{
			bk.tvs();
			bk.display();
		}
		else if(b.equals("ducati"))
		{
			bk.ducati();
			bk.display();
		}
		else
		{
			System.out.println("invalid entry........");
		
			
			
		}
	

	

}
}
