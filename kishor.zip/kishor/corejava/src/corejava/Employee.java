package corejava;

public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SetterGetter sg=new SetterGetter();
		sg.setId(101);
		sg.setName("kishor");
		sg.setAddress("mumbai");
		System.out.println(sg.getId());
		System.out.println(sg.getName());
		System.out.println(sg.getAddress());
		
		
	}

}
