package com.test.basic;

public interface Player {

	 void m1();

}
