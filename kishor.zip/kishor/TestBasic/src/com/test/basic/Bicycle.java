package com.test.basic;

public class Bicycle {

	public void m4() {

		System.out.println("from m4");
		
	}
	
}
