package com.test.basic;

public class TestInterfaceExample extends Bicycle implements Player, Student {
	/*  */

	public static void main(String[] args) {

		TestInterfaceExample t = new TestInterfaceExample();

		t.m1();
		t.m2();
		//t.m3();

	}

	@Override
	public void m1() {

		System.out.println("hi ");

	}

	@Override
	public void m2() {

		System.out.println("from student public");
	}
	
	
	
}
