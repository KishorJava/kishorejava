package com.test.basic;

public abstract class TestAbstarct {

	public static void m1() {

		System.out.println("from static");
	}

}
