package com.test.basic;

import com.example.access.specifiers.TestProtectedexampleClass;

public class Vehicle extends TestProtectedexampleClass {

	void m3() {
		System.out.println("from class vehicle and m3 method");
	}

	

	
}
