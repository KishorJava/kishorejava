package com.test.basic;

interface Student {

	public void m2();

	
	
}
