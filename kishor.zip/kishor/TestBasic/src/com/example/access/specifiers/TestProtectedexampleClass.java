package com.example.access.specifiers;

public class TestProtectedexampleClass {

	
	 void m8() {
		System.out.println("from protected class m8");
	}
}
